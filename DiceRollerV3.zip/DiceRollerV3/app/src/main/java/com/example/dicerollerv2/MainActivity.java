package com.example.dicerollerv2;

import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int userScore = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onButtonClick(View view){

        // Generates the random value
        TextView outputTV = this.findViewById(R.id.generatedTV);
        Random r = new Random();
        int number = r.nextInt(7);
        outputTV.setText(Integer.toString(number));

        // Gets the user's input
        final EditText inputET = findViewById(R.id.userInputET);
        String userInput = inputET.getText().toString();
        final int guessedNum = getGuessedNum(userInput);
        // add a pop up warning the user that only numbers are allowed


        // Gets the generated value
        final TextView outputValue = findViewById(R.id.generatedTV);
        String randOutput = (String) outputValue.getText();
        final int generatedValue = getGuessedNum(randOutput);
        /* Call the 'Congratulations' object and have its' visibility
         * set depending on the condition.
         */
        final TextView congrats = findViewById(R.id.congratsTV);
        final TextView score = findViewById(R.id.incrementingTV);
        try{
            if(guessedNum == generatedValue){
                congrats.setVisibility(view.VISIBLE);
                this.userScore ++;
                score.setText(Integer.toString(userScore));
            }
            else {
                congrats.setVisibility(view.INVISIBLE);
                //userScore = 0;
                //score.setText(Integer.toString(userScore));
            }
        } catch (Exception ex){
            System.out.println(ex);}
    }

    private int getGuessedNum(String userInput) {
        try {
            return Integer.parseInt(userInput);
        } catch (NumberFormatException ex ) {
            Log.e("NumberParsing", ex.toString());
            return  -1;
        }
    }
}
